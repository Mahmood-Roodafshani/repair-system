export default function Cartbot() {
  return <div>Cartbot</div>
}
