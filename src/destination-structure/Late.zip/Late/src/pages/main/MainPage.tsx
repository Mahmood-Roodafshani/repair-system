import { mainSystems, notifications } from '@/constant'
import { CustomThemeType } from '@/types'
import { useTheme } from '@emotion/react'
import { Grid2, Typography } from '@mui/material'
import { Link } from 'react-router-dom'

export default function MainPage() {
  const theme = useTheme() as CustomThemeType

  return (
    <Grid2 display='flex' flexWrap='wrap' justifyContent='space-between' gap='5px'>
      {notifications.map((notification: { id: number; title: string; url: string }) => (
        <Grid2
          sx={{
            cursor: 'pointer',
            '&:hover': {
              backgroundColor: theme.palette.secondary.contrastText,
            },
          }}
          width='33%'
          height={100}
          bgcolor={theme.palette.secondary.main}
          display='flex'
          justifyContent='center'
          alignItems='center'
          padding={2}
          border='1px solid #ccc'
          borderRadius={5}
          component={Link}
          to={notification.url}
        >
          <Typography fontWeight='bold'>{notification.title}</Typography>
        </Grid2>
      ))}
      <Grid2 width='100%' height='1px' bgcolor='#ccc' margin='20px 0' />
      {mainSystems.map((item: { id: number; title: string; url: string }) => (
        <Grid2
          sx={{
            cursor: 'pointer',
            '&:hover': {
              backgroundColor: theme.palette.primary.main,
            },
          }}
          width='33%'
          height={150}
          display='flex'
          bgcolor={theme.palette.primary.light}
          justifyContent='center'
          alignItems='center'
          padding={2}
          border='1px solid #ccc'
          borderRadius={5}
          component={Link}
          to={item.url}
        >
          <Typography fontWeight='bold' color='white'>
            {item.title}
          </Typography>
        </Grid2>
      ))}
    </Grid2>
  )
}
