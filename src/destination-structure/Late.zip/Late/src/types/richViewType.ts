export type RichViewType = {
  id: string;
  label: string;
  children?: RichViewType[];
}; 