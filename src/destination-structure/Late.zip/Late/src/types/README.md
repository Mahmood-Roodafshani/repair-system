# Types

The `types` folder contains TypeScript type definitions and interfaces used throughout the application. By centralizing type definitions in this folder, we ensure consistency and reusability across the project. It also helps with type safety, making it easier to maintain and extend the codebase.

## Folder Structure

- **`api.d.ts`**: Contains type definitions related to API responses and request payloads.
- **`user.d.ts`**: Defines types related to user data and user-related operations.
- **`theme.d.ts`**: Contains types related to theme configuration (e.g., light/dark mode).

## Benefits of Centralizing Types

1. **Type Safety**: Centralizing type definitions ensures that every part of the application uses consistent data structures, reducing errors and improving maintainability.
2. **Reusability**: You can reuse types across multiple components and services, avoiding duplication and ensuring consistency.
3. **IntelliSense Support**: With TypeScript, using types and interfaces from the `types` folder provides autocompletion and error checking in your IDE, making development faster and less error-prone.

## Example of Type Definitions

### `api.d.ts`

```typescript
// api.d.ts

export interface ApiResponse<T> {
  data: T
  status: number
  message: string
}

export interface UserData {
  id: string
  name: string
  email: string
}
```
