# Utils

The `utils` folder contains helper functions and utility methods that are used throughout the application. These functions are designed to be reusable, generic, and optimized for common operations that don't belong to a specific component or service.

## Folder Structure

- **`dateUtils.ts`**: Contains helper functions for handling date and time operations (e.g., formatting, parsing).
- **`stringUtils.ts`**: Includes utility functions for string manipulation (e.g., trimming, capitalizing, etc.).
- **`numberUtils.ts`**: Provides helper methods for handling numeric operations (e.g., formatting numbers, rounding).
- **`arrayUtils.ts`**: Utility functions for array operations (e.g., filtering, mapping).
- **`validationUtils.ts`**: Contains commonly used validation functions for inputs like emails, phone numbers, etc.

## Why Use the `utils` Folder?

The `utils` folder provides centralized and reusable helper functions that help avoid code duplication and reduce clutter in the main application logic. By abstracting common logic into utility functions, we keep the rest of the codebase clean, readable, and maintainable.

## Example of Utility Functions

### `dateUtils.ts`

```typescript
// dateUtils.ts

export const formatDate = (date: Date | string, format: string = 'YYYY-MM-DD'): string => {
  const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: '2-digit', day: '2-digit' }
  return new Date(date).toLocaleDateString(undefined, options)
}

export const parseDate = (dateString: string): Date => {
  return new Date(dateString)
}
```
