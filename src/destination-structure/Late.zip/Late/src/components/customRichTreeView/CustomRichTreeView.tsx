import AddBoxIcon from '@mui/icons-material/AddBox';
import IndeterminateCheckBoxIcon from '@mui/icons-material/IndeterminateCheckBox';
import { Grid, Stack, Typography } from '@mui/material';
import { alpha, styled } from '@mui/material/styles';
import { RichTreeView } from '@mui/x-tree-view';
import { TreeItem, treeItemClasses } from '@mui/x-tree-view/TreeItem';
import { useEffect, useState } from 'react';
import { RichViewType } from '@/types/richViewType';
import {
  findAllNodesWithChild,
  findAllParents,
  findLeafs
} from '@/utils/helper';

interface CustomRichTreeViewProps {
  sx?: any;
  label?: string;
  items: RichViewType[];
  defaultValue?: string[];
  onSelectedItemsChange?: (event: React.SyntheticEvent, itemIds: any) => void;
  error?: string;
  justSelectLeaf?: boolean;
  multiSelect?: boolean;
  checkboxSelection?: boolean;
  expandAllItems?: boolean;
  clearFlag?: boolean;
}

function CustomRichTreeView({
  sx = { width: '500px' },
  label,
  items,
  defaultValue,
  onSelectedItemsChange,
  error,
  justSelectLeaf = false,
  multiSelect = false,
  checkboxSelection = false,
  expandAllItems = false,
  clearFlag = false
}: CustomRichTreeViewProps) {
  const [expandedItems, setExpandedItems] = useState<string[]>();
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [leafs, setLeafs] = useState<string[]>();

  useEffect(() => {
    if (justSelectLeaf) setLeafs(findLeafs(items));
  }, [justSelectLeaf]);

  useEffect(() => {
    if (defaultValue !== undefined && defaultValue.length > 0)
      setSelectedItems(defaultValue);
  }, [defaultValue]);

  useEffect(() => {
    if (clearFlag) setSelectedItems([]);
  }, [clearFlag]);

  useEffect(() => {
    if (expandAllItems) setExpandedItems(findAllNodesWithChild(items));
  }, [expandAllItems]);

  useEffect(() => {
    if (expandAllItems || expandedItems?.length > 0) return;
    if (defaultValue === undefined || defaultValue.length === 0) {
      setExpandedItems([]);
      return;
    }
    let allParents: string[] = [];
    for (const node of defaultValue) {
      const parents = findAllParents(node, items);
      for (const parent of parents) {
        if (!allParents.includes(parent.id)) {
          allParents.push(parent.id);
        }
      }
    }
    setExpandedItems(allParents);
  }, [defaultValue, expandAllItems]);

  useEffect(() => {
    if (
      expandedItems === undefined ||
      expandedItems.length > 0 ||
      items?.length > 1 ||
      expandAllItems
    )
      return;

    setExpandedItems([items[0].id]);
  }, [items, expandedItems, expandAllItems]);

  const CustomTreeItem = styled(TreeItem)(({ theme }) => ({
    color: theme.palette.grey[200],
    [`& .${treeItemClasses.content}`]: {
      borderRadius: theme.spacing(0.5),
      padding: theme.spacing(0.5, 1),
      margin: theme.spacing(0.2, 0),
      [`& .${treeItemClasses.label}`]: {
        fontSize: '0.8rem',
        fontWeight: 500
      }
    },
    [`& .${treeItemClasses.selected}`]: {
      backgroundColor: alpha(theme.palette.primary.main, 0.2),
      '&:hover': {
        backgroundColor: alpha(theme.palette.primary.main, 0.3)
      }
    }
  }));

  return (
    <Stack spacing={1}>
      {label && (
        <Typography variant="subtitle2" color="text.secondary">
          {label}
        </Typography>
      )}
      <Grid
        sx={{
          ...sx,
          border: error ? `1px solid ${error}` : undefined,
          borderRadius: 1,
          p: 1
        }}
      >
        <RichTreeView
          aria-label="rich tree view"
          defaultCollapseIcon={<IndeterminateCheckBoxIcon />}
          defaultExpandIcon={<AddBoxIcon />}
          expanded={expandedItems}
          selected={selectedItems}
          multiSelect={multiSelect}
          checkboxSelection={checkboxSelection}
          onNodeSelect={(event: React.SyntheticEvent, itemIds: any) => {
            if (justSelectLeaf && leafs) {
              const selectedLeafs = Array.isArray(itemIds)
                ? itemIds.filter((id) => leafs.includes(id))
                : leafs.includes(itemIds)
                ? [itemIds]
                : [];
              setSelectedItems(selectedLeafs);
              onSelectedItemsChange?.(event, selectedLeafs);
              return;
            }
            setSelectedItems(Array.isArray(itemIds) ? itemIds : [itemIds]);
            onSelectedItemsChange?.(event, itemIds);
          }}
          onNodeToggle={(event: React.SyntheticEvent, itemIds: string[]) => {
            setExpandedItems(itemIds);
          }}
          slots={{ item: CustomTreeItem }}
          items={items}
        />
      </Grid>
      {error && (
        <Typography variant="caption" color="error">
          {error}
        </Typography>
      )}
    </Stack>
  );
}

export default CustomRichTreeView; 