import { Button, ButtonProps } from '@mui/material'

interface CustomButtonProps extends ButtonProps {
  label: string
  type?: 'submit' | 'button'
}

const CustomButton: React.FC<CustomButtonProps> = ({ label, type = 'button', ...props }) => {
  return (
    <Button type={type} fullWidth variant='contained' color='primary' sx={{ mt: 2 }} {...props}>
      {label}
    </Button>
  )
}

export default CustomButton
