import * as React from 'react';
import SearchIcon from '@mui/icons-material/Search';
import AddIcon from '@mui/icons-material/Add';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import DeleteIcon from '@mui/icons-material/Delete';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import SaveIcon from '@mui/icons-material/Save';
import EditIcon from '@mui/icons-material/Edit';
import VisibilityIcon from '@mui/icons-material/Visibility';
import PrintIcon from '@mui/icons-material/Print';
import CheckIcon from '@mui/icons-material/Check';
import CancelIcon from '@mui/icons-material/Cancel';
import CloseIcon from '@mui/icons-material/Close';
import RefreshIcon from '@mui/icons-material/Refresh';
import ClearAllIcon from '@mui/icons-material/ClearAll';
import UndoIcon from '@mui/icons-material/Undo';

export default class ButtonType {
  static readonly SEARCH = new ButtonType(<SearchIcon />, null, 'search');
  static readonly CREATE = new ButtonType(<AddIcon />, null, 'create');
  static readonly SHOW_ALL = new ButtonType(<AutorenewIcon />, null, 'showAll');
  static readonly ADD = new ButtonType(<AddIcon />, null, 'add');
  static readonly DELETE = new ButtonType(<DeleteIcon />, null, 'delete');
  static readonly REPORT = new ButtonType(<FileDownloadIcon />, null, 'report');
  static readonly SAVE = new ButtonType(<SaveIcon />, null, 'save');
  static readonly EDIT = new ButtonType(<EditIcon />, null, 'edit');
  static readonly DISPLAY = new ButtonType(<VisibilityIcon />, null, 'display');
  static readonly PRINT = new ButtonType(<PrintIcon />, null, 'print');
  static readonly ACCEPT = new ButtonType(<CheckIcon />, null, 'ok');
  static readonly REJECT = new ButtonType(<CancelIcon />, null, 'reject');
  static readonly YES = new ButtonType(<CheckIcon />, null, 'yes');
  static readonly NO = new ButtonType(<CancelIcon />, null, 'no');
  static readonly CANCEL = new ButtonType(<CancelIcon />, null, 'cancel');
  static readonly CLOSE = new ButtonType(<CloseIcon />, null, 'close');
  static readonly DOWNLOAD = new ButtonType(<FileDownloadIcon />, null, 'download');
  static readonly UPLOAD = new ButtonType(<FileDownloadIcon />, null, 'upload');
  static readonly REFRESH = new ButtonType(<RefreshIcon />, null, 'update');
  static readonly CLEAR = new ButtonType(<ClearAllIcon />, null, 'clear');
  static readonly UNDO = new ButtonType(<UndoIcon />, null, 'cancel');
  static readonly CREATE_OR_EDIT = new ButtonType(<EditIcon />, null, 'create/edit');

  icon: React.ReactElement;
  text: string | React.ReactNode;
  defaultMessage: string | null;

  constructor(
    icon: React.ReactElement,
    text?: string | React.ReactNode,
    defaultMessage?: string
  ) {
    if (text != null && defaultMessage != null) {
      throw Error('Only one of "text" or "defaultMessage" is allowed');
    }
    if (text == null && defaultMessage == null) {
      throw Error('One of "text" or "defaultMessage" is required');
    }
    this.icon = icon;
    this.text = text;
    this.defaultMessage = defaultMessage ? defaultMessage : null;
  }
} 