import * as React from 'react';
import { InputLabel as MInputLabel, InputLabelProps } from '@mui/material';

interface LabelProps extends InputLabelProps {
  required?: boolean;
  error?: boolean;
}

function Label(props: LabelProps) {
  const { children, required, error, ...otherProps } = props;

  return (
    <MInputLabel
      error={error}
      required={required}
      {...otherProps}
    >
      {children}
    </MInputLabel>
  );
}

export default Label; 