# Hooks

This folder contains custom React hooks that encapsulate reusable logic, improving code modularity and maintainability across the project.

## Structure

The `hooks` folder includes custom hooks that provide specific functionality throughout the application. Each hook is designed to handle a distinct piece of logic that can be reused in multiple components.

### Common Hooks in this Folder:

- **useAuth.js**: A custom hook for managing authentication and user login/logout.
- **useFetch.js**: A custom hook for handling API requests (GET, POST, etc.).
- **useLocalStorage.js**: A custom hook for interacting with the browser's `localStorage`.
- **useDebounce.js**: A custom hook for debouncing user inputs (useful for search bars or filters).
- **usePrevious.js**: A custom hook to get the previous value of a state variable.

## Usage

To use a custom hook in your components, simply import it and call it inside your component.

### Example of Using `useFetch`:

```javascript
import useFetch from '@/hooks/useFetch'

const UserList = () => {
  const { data, error, isLoading } = useFetch('https://jsonplaceholder.typicode.com/users')

  if (isLoading) return <p>Loading...</p>
  if (error) return <p>Error: {error.message}</p>

  return (
    <ul>
      {data.map((user) => (
        <li key={user.id}>{user.name}</li>
      ))}
    </ul>
  )
}
```
