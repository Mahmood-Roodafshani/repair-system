import { createTheme, responsiveFontSizes } from '@mui/material/styles';
import type {} from '@mui/x-date-pickers/themeAugmentation';
import { ExtendedThemeOptions } from '../types';
import { grey, blue } from '@mui/material/colors';
import { ThemeOptions } from '@mui/material/styles';

const baseThemeOptions: ExtendedThemeOptions = {
  direction: 'rtl',
  palette: {
    mode: 'dark',
    common: {
      black: '#000000',
      white: '#ffffff',
    },
    primary: {
      main: '#90caf9',
      light: '#e3f2fd',
      dark: '#42a5f5',
      contrastText: '#000000',
    },
    secondary: {
      main: '#ce93d8',
      light: '#f3e5f5',
      dark: '#ab47bc',
      contrastText: '#000000',
    },
    error: {
      main: '#f44336',
      light: '#e57373',
      dark: '#d32f2f',
      contrastText: '#ffffff',
    },
    warning: {
      main: '#ffa726',
      light: '#ffb74d',
      dark: '#f57c00',
      contrastText: '#000000',
    },
    info: {
      main: '#29b6f6',
      light: '#4fc3f7',
      dark: '#0288d1',
      contrastText: '#000000',
    },
    success: {
      main: '#66bb6a',
      light: '#81c784',
      dark: '#388e3c',
      contrastText: '#000000',
    },
    grey: {
      50: '#fafafa',
      100: '#f5f5f5',
      200: '#eeeeee',
      300: '#e0e0e0',
      400: '#bdbdbd',
      500: '#9e9e9e',
      600: '#757575',
      700: '#616161',
      800: '#424242',
      900: '#212121',
      A100: '#f5f5f5',
      A200: '#eeeeee',
      A400: '#bdbdbd',
      A700: '#616161',
    },
    text: {
      primary: '#ffffff',
      secondary: 'rgba(255, 255, 255, 0.7)',
      disabled: 'rgba(255, 255, 255, 0.5)',
    },
    divider: 'rgba(255, 255, 255, 0.12)',
    background: {
      default: '#121212',
      paper: '#1e1e1e',
    },
    action: {
      active: '#ffffff',
      hover: 'rgba(255, 255, 255, 0.08)',
      hoverOpacity: 0.08,
      selected: 'rgba(255, 255, 255, 0.16)',
      selectedOpacity: 0.16,
      disabled: 'rgba(255, 255, 255, 0.3)',
      disabledBackground: 'rgba(255, 255, 255, 0.12)',
      disabledOpacity: 0.38,
      focus: 'rgba(255, 255, 255, 0.12)',
      focusOpacity: 0.12,
      activatedOpacity: 0.24,
    },
    contrastThreshold: 3,
    tonalOffset: 0.2,
  },
  typography: {
    htmlFontSize: 16,
    fontFamily: 'IRANSans, Roboto, Arial',
    fontSize: 14,
    fontWeightLight: 300,
    fontWeightRegular: 400,
    fontWeightMedium: 500,
    fontWeightBold: 700,
    h1: {
      fontSize: '2.5rem',
      fontWeight: 600,
    },
    h2: {
      fontSize: '2rem',
      fontWeight: 600,
    },
    h3: {
      fontSize: '1.75rem',
      fontWeight: 600,
    },
    h4: {
      fontSize: '1.5rem',
      fontWeight: 600,
    },
    h5: {
      fontSize: '1.25rem',
      fontWeight: 600,
    },
    h6: {
      fontSize: '1rem',
      fontWeight: 600,
    },
    subtitle1: {
      fontSize: '1rem',
      fontWeight: 400,
    },
    subtitle2: {
      fontSize: '0.875rem',
      fontWeight: 500,
    },
    body1: {
      fontSize: '1rem',
      fontWeight: 400,
    },
    body2: {
      fontSize: '0.875rem',
      fontWeight: 400,
    },
    button: {
      fontSize: '0.875rem',
      fontWeight: 500,
      textTransform: 'none',
    },
    caption: {
      fontSize: '0.75rem',
      fontWeight: 400,
    },
    overline: {
      fontSize: '0.75rem',
      fontWeight: 600,
      textTransform: 'uppercase',
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          borderRadius: 8,
        },
      },
    },
    MuiDrawer: {
      styleOverrides: {
        paper: {
          backgroundColor: '#1e1e1e',
        },
      },
    },
  },
  colors: {
    gradients: {
      blue1: '#90caf9',
      blue2: '#42a5f5',
      blue3: '#1976d2',
      blue4: '#1565c0',
      blue5: '#0d47a1',
      orange1: '#ffa726',
      orange2: '#f57c00',
      orange3: '#ef6c00',
      purple1: '#ce93d8',
      purple3: '#ab47bc',
      pink1: '#f48fb1',
      pink2: '#f06292',
      green1: '#66bb6a',
      green2: '#4caf50',
      black1: '#000000',
      black2: '#121212',
    },
    shadows: {
      success: '#66bb6a',
      error: '#f44336',
      primary: '#90caf9',
      warning: '#ffa726',
      info: '#29b6f6',
    },
    alpha: {
      white: {
        5: 'rgba(255, 255, 255, 0.05)',
        10: 'rgba(255, 255, 255, 0.1)',
        30: 'rgba(255, 255, 255, 0.3)',
        50: 'rgba(255, 255, 255, 0.5)',
        70: 'rgba(255, 255, 255, 0.7)',
        100: '#ffffff',
      },
      trueWhite: {
        5: 'rgba(255, 255, 255, 0.05)',
        10: 'rgba(255, 255, 255, 0.1)',
        30: 'rgba(255, 255, 255, 0.3)',
        50: 'rgba(255, 255, 255, 0.5)',
        70: 'rgba(255, 255, 255, 0.7)',
        100: '#ffffff',
      },
      black: {
        5: 'rgba(0, 0, 0, 0.05)',
        10: 'rgba(0, 0, 0, 0.1)',
        30: 'rgba(0, 0, 0, 0.3)',
        50: 'rgba(0, 0, 0, 0.5)',
        70: 'rgba(0, 0, 0, 0.7)',
        100: '#000000',
      },
    },
    primary: {
      lighter: '#e3f2fd',
      light: '#90caf9',
      main: '#42a5f5',
      dark: '#1976d2',
    },
    secondary: {
      lighter: '#f3e5f5',
      light: '#ce93d8',
      main: '#ab47bc',
      dark: '#8e24aa',
    },
    success: {
      lighter: '#81c784',
      light: '#66bb6a',
      main: '#4caf50',
      dark: '#388e3c',
    },
    warning: {
      lighter: '#ffb74d',
      light: '#ffa726',
      main: '#f57c00',
      dark: '#ef6c00',
    },
    error: {
      lighter: '#e57373',
      light: '#ef5350',
      main: '#f44336',
      dark: '#d32f2f',
    },
    info: {
      lighter: '#4fc3f7',
      light: '#29b6f6',
      main: '#0288d1',
      dark: '#01579b',
    },
    custom: {
      darkBlue: '#1976d2',
      lightBlue: '#90caf9',
      pink: '#f48fb1',
    },
  },
  general: {
    reactFrameworkColor: '#00D8FF',
    borderRadiusSm: '4px',
    borderRadius: '8px',
    borderRadiusLg: '12px',
    borderRadiusXl: '16px',
  },
  sidebar: {
    background: '#1e1e1e',
    boxShadow: '0 0 2px 0 rgba(0, 0, 0, 0.2), 0 3px 4px 2px rgba(0, 0, 0, 0.1)',
    width: '280px',
    right: '0',
    left: 'auto',
    textColor: '#ffffff',
    dividerBg: '#424242',
    menuItemColor: '#ffffff',
    menuItemColorActive: '#90caf9',
    menuItemBg: '#1e1e1e',
    menuItemBgActive: '#1976d2',
    menuItemIconColor: '#9e9e9e',
    menuItemIconColorActive: '#90caf9',
    menuItemHeadingColor: '#9e9e9e',
  },
  header: {
    height: '64px',
    background: '#1e1e1e',
    boxShadow: '0 0 2px 0 rgba(0, 0, 0, 0.2), 0 3px 4px 2px rgba(0, 0, 0, 0.1)',
    textColor: '#ffffff',
  },
  footer: {
    height: '48px',
    background: '#1e1e1e',
    color: '#ffffff',
  },
};

export const PureDarkTheme = createTheme(baseThemeOptions); 