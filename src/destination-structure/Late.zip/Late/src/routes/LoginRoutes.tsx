import { Login } from '@/pages'
import { Route, Routes } from 'react-router'

export default function LoginRoutes() {
  return (
    <Routes>
      <Route path='/' element={<Login />} />
    </Routes>
  )
}
