# Localization

This folder contains the language files and logic for handling localization (l10n) and language switching in the project. It provides support for multiple languages by managing translations and applying direction (LTR/RTL) and font settings based on the selected language.

## Structure

The `localization` folder includes language files that contain the translated strings for each language, and a configuration file to manage the active language, text direction, and font.

### Files in this Folder:

- **en.js**: English translation file.
- **fa.js**: Persian (Farsi) translation file.
- **index.js** (or similar): The configuration file that handles the active language, direction, font, and switching between languages.

## Usage

The logic for localization is handled using JavaScript by reading and switching languages stored in `localStorage`.

### Example of how to use translations in your components:

1. **Import `translate` and `direction`** to dynamically display content in the correct language.

```javascript
import { translate, direction, getFonts, changeLanguage } from '@/localization'

const Header = () => {
  return (
    <header style={{ fontFamily: getFonts() }}>
      <h1>{translate.welcome_message}</h1>
    </header>
  )
}

const SwitchLanguageButton = () => {
  return <button onClick={changeLanguage}>{translate.change_language_button}</button>
}
```
