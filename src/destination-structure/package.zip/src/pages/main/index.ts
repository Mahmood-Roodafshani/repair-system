export { default as MainPage } from './MainPage';
