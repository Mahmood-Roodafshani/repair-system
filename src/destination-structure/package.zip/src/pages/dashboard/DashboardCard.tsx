import { Grid, Typography, styled } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const StyledCard = styled(Grid)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  position: 'relative',
  cursor: 'pointer',
  fontWeight: 'bold',
  fontSize: '1.1rem',
  height: '90px',
  padding: '0 20px',
  borderRadius: '12px',
  transition: theme.transitions.create(['transform', 'box-shadow']),
  '&:hover': {
    transform: 'translateY(-3px)',
    boxShadow: theme.shadows[4],
  }
}));

const TopCard = styled(StyledCard)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' 
    ? theme.palette.primary.dark
    : theme.palette.primary.main,
  border: `3px solid ${theme.palette.mode === 'dark' 
    ? theme.palette.secondary.main
    : theme.palette.primary.light}`,
  color: theme.palette.mode === 'dark' 
    ? theme.palette.secondary.main
    : theme.palette.primary.contrastText,
  '&:hover': {
    backgroundColor: theme.palette.mode === 'dark'
      ? theme.palette.primary.main
      : theme.palette.primary.light,
    borderColor: theme.palette.mode === 'dark'
      ? theme.palette.secondary.light
      : theme.palette.primary.main,
  }
}));

const BottomCard = styled(StyledCard)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark'
    ? theme.palette.primary.main
    : theme.palette.primary.light,
  color: theme.palette.primary.contrastText,
  '&:hover': {
    backgroundColor: theme.palette.mode === 'dark'
      ? theme.palette.primary.dark
      : theme.palette.primary.main,
  }
}));

const NotificationCounter = styled('div')(({ theme }) => ({
  position: 'absolute',
  top: -8,
  right: -8,
  backgroundColor: theme.palette.error.main,
  color: theme.palette.error.contrastText,
  borderRadius: '50%',
  width: '24px',
  height: '24px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '0.75rem',
  fontWeight: 'bold',
}));

interface DashboardCardProps {
  variant: 'top' | 'bottom';
  title: string;
  notifications?: number;
  onClick?: () => void;
  to?: string;
}

const DashboardCard: React.FC<DashboardCardProps> = ({ 
  variant, 
  title, 
  notifications, 
  onClick, 
  to 
}) => {
  const navigate = useNavigate();
  const Card = variant === 'top' ? TopCard : BottomCard;

  const handleClick = () => {
    if (onClick) {
      onClick();
    } else if (to) {
      navigate(to);
    }
  };

  return (
    <Card item onClick={handleClick}>
      {notifications && <NotificationCounter>{notifications}</NotificationCounter>}
      <Typography variant="h6" align="center">
        {title}
      </Typography>
    </Card>
  );
};

export default DashboardCard; 