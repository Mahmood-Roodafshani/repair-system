import { CustomButton, CustomInput } from '@/components';
import { translate } from '@/localization';
import { doLogin } from '@/redux/slices/userSlice';
import { useAppDispatch } from '@/redux/store';
import { DoLoginService } from '@/services/authentication';
import { yupResolver } from '@hookform/resolvers/yup';
import { Grid2, Typography } from '@mui/material';
import { SubmitHandler, useForm } from 'react-hook-form';
import * as yup from 'yup';

interface ILoginForm {
  username: string;
  password: string;
}

const schema = yup
  .object({
    username: yup.string().required('Username is required'),
    password: yup.string().required('Password is required')
  })
  .required();

const Login: React.FC = () => {
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm<ILoginForm>({
    resolver: yupResolver(schema)
  });
  const dispatch = useAppDispatch();

  const onSubmit: SubmitHandler<ILoginForm> = (data) => {
    console.log(data);
    DoLoginService(data).then((res) => {
      if (res.status === 200) {
        console.log(data);
        dispatch(doLogin({ token: res.data.token }));
      } else {
        dispatch(doLogin({ token: res.data.token }));
        // alert('Invalid username or password')
      }
    });
  };

  return (
    <Grid2
      container
      justifyContent="center"
      alignItems="center"
      style={{ minHeight: '100vh' }}
    >
      <Grid2>
        <Typography variant="h5" gutterBottom>
          {translate.login_page.title}
        </Typography>
        <form onSubmit={handleSubmit(onSubmit)}>
          <CustomInput
            label={translate.login_page.username}
            name="username"
            register={register}
            error={errors.username?.message}
            helperText={errors.username?.message}
          />
          <CustomInput
            label={translate.login_page.password}
            name="password"
            type="password"
            register={register}
            error={errors.password?.message}
            helperText={errors.password?.message}
          />
          <CustomButton label="Log In" type="submit" />
        </form>
      </Grid2>
    </Grid2>
  );
};

export default Login;
