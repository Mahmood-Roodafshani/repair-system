import ChangeTheme from '@/components/changeTheme/ChangeTheme';
import { changeLanguage } from '@/localization';
import { LoginRoutes } from '@/routes';
import LanguageIcon from '@mui/icons-material/Language';
import { Grid2, IconButton } from '@mui/material';

const AuthLayout: React.FC = () => {
  return (
    <Grid2 display="flex">
      <Grid2 position="absolute" top={5} right={5}>
        <IconButton onClick={() => changeLanguage()}>
          <LanguageIcon />
        </IconButton>
        <ChangeTheme />
      </Grid2>
      <Grid2
        width="65%"
        height="100vh"
        bgcolor="#eee"
        display="flex"
        justifyContent="center"
        alignItems="center"
      >
        Logo
      </Grid2>
      <Grid2
        width="35%"
        padding="3%"
        height="100vh"
        display="flex"
        justifyContent="center"
        alignItems="center"
      >
        <LoginRoutes />
      </Grid2>
    </Grid2>
  );
};

export default AuthLayout;
