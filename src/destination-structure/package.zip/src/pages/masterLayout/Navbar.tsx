import { translate } from '@/localization';
import { doLogout } from '@/redux/slices/userSlice';
import { useAppDispatch } from '@/redux/store';
import { Avatar, Grid2, IconButton, Typography } from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';

export default function Navbar() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const handleLogout = () => {
    dispatch(doLogout());
    navigate('/');
  };

  return (
    <Grid2
      display="flex"
      justifyContent="space-between"
      alignItems="center"
      borderBottom="1px solid rgba(0, 0, 0, 0.1)"
      bgcolor="#fff"
      zIndex={2}
      position="fixed"
      height={55}
      width="100%"
      padding="0 20px"
    >
      <Typography>Logo</Typography>

      <Grid2 component={Link} to={'/'}>
        <Typography variant="h6" noWrap component="div">
          {translate.common.app_name}
        </Typography>
      </Grid2>
      <IconButton onClick={handleLogout}>
        <Avatar
          alt="Remy Sharp"
          src="https://mui.com/static/images/avatar/2.jpg"
        />
      </IconButton>
    </Grid2>
  );
}
