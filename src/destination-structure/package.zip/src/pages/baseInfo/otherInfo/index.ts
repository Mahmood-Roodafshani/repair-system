export { default as OtherInfo } from './OtherInfo';
