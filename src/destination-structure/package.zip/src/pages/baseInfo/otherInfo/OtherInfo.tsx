import { CustomButton, CustomInput } from '@/components';
import { translate } from '@/localization';
import { yupResolver } from '@hookform/resolvers/yup';
import { Grid2 } from '@mui/material';
import { useForm } from 'react-hook-form';
import * as yup from 'yup';

interface IOtherInfoForm {
  username: string;
  password: string;
}

const schema = yup
  .object({
    username: yup.string().required('Username is required'),
    password: yup.string().required('Password is required')
  })
  .required();

const OtherInfo: React.FC = () => {
  const {
    register,
    formState: { errors }
  } = useForm<IOtherInfoForm>({
    resolver: yupResolver(schema)
  });

  return (
    <Grid2 display="flex" flexWrap="wrap">
      <CustomInput
        label={translate.pages.baseInfo.otherInfo.name}
        name="username"
        register={register}
        error={errors.username?.message}
        helperText={errors.username?.message}
      />
      <CustomInput
        label={translate.pages.baseInfo.otherInfo.family}
        name="password"
        type="password"
        register={register}
        error={errors.password?.message}
        helperText={errors.password?.message}
      />
      <CustomInput
        label={translate.pages.baseInfo.otherInfo.fatherName}
        name="password"
        type="password"
        register={register}
        error={errors.password?.message}
        helperText={errors.password?.message}
      />
      <CustomInput
        label={translate.pages.baseInfo.otherInfo.nationalCode1}
        name="password"
        type="password"
        register={register}
        error={errors.password?.message}
        helperText={errors.password?.message}
      />
      <CustomInput
        label={translate.pages.baseInfo.otherInfo.nationalCode2}
        name="password"
        type="password"
        register={register}
        error={errors.password?.message}
        helperText={errors.password?.message}
      />
      <CustomButton label="Log In" type="submit" />
    </Grid2>
  );
};

export default OtherInfo;
