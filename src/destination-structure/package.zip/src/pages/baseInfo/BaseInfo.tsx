import { Outlet } from 'react-router-dom';

export default function BaseInfo() {
  return (
    <div>
      BaseInfo
      <Outlet />
    </div>
  );
}
