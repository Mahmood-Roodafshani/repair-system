export { default as FamilyInfo } from './FamilyInfo';
