export default function FamilyInfo() {
  return <div>FamilyInfo</div>;
}
