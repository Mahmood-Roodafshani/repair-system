import { Route, Routes } from 'react-router-dom';
import {
  StaffInfo,
  FamilyInfo,
  MainPage,
  Cartbot,
  BaseInfo,
  Maintenance,
  OtherInfo
} from '@/pages';

export default function MainRoutes() {
  return (
    <Routes>
      <Route path="/maintenance" element={<Maintenance />}>
        <Route path="cart-bot" element={<Cartbot />} />
      </Route>

      <Route path="/baseInfo" >
        <Route index element={<BaseInfo />} />
        <Route path="staff-info" element={<StaffInfo />} />
        <Route path="family-info" element={<FamilyInfo />} />
        <Route path="other-info" element={<OtherInfo />} />
      </Route>

      <Route path="/" element={<MainPage />} />
    </Routes>
  );
}
