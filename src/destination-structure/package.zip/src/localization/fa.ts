const fa = {
  common: {
    app_name: 'سامانه جامع',
    change_lang: 'تغییر زبان'
  },
  login_page: {
    title: 'ورود',
    username: 'نام کاربری',
    password: 'رمز عبور'
  },

  main_page: {
    info: {
      inbox: 'کارتابل عمومی',
      warning: 'هشدارها',
      notifications: 'اعلان ها'
    },
    modules: {
      dashboard: 'داشبورد',
      usernmngment: 'مدیریت کاربران',
      repair: 'سامانه تعمیرات',
      jobs: 'سامانه مشاغل',
      flow: 'سامانه پیگیری',
      coding: 'سامانه کدینگ',
      base: 'اطلاعات پایه'
    }
  },
  validation: {
    username_required: 'نام کاربری الزامی است',
    password_required: 'رمز عبور الزامی است'
  },
  menu: {
    maintenance: {
      cartable: 'کارتابل',
      repair_request: 'درخواست تعمیر',
      content_report: 'گزارش محتوا',
      group_performance_report: 'گزارش عملکرد یگانی',
      individual_performance_report: 'گزارش عملکرد فردی',
      techniqual_agent: 'رابط فنی',
      commision: 'کمیسیون',
      rent_items: 'اقلام امانی',
      items_list: 'لیست اقلام',
      companies: 'شرکت ها',
      code_to_item: 'اتصال کد اموال به گروه',
      miss_req: 'درخواست مفقودی',
      exit_list: 'چاپ برگه خروج',
      system_proccess: 'فرآیند سامانه'
    },
    base: {
      staff_info: 'اطلاعات پرسنل',
      family_info: 'اطلاعات خانواده',
      other_info: 'سایر اطلاعات',
    }
  },
  pages: {
    baseInfo: {
      otherInfo: {
        name: 'نام',
        family: 'نام خانوادگی',
        nationalCode1: 'کد ملی',
        nationalCode2: 'شماره شناسنامه',
        fatherName: 'نام پدر',
      }
    }
  }
};
export default fa;
