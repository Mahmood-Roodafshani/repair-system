const en = {
  common: {
    app_name: 'General System',
    change_lang: 'Change Language'
  },
  login_page: {
    title: 'Login',
    username: 'Username',
    password: 'Password'
  },
  main_page: {
    info: {
      inbox: 'Public inbox',
      warning: 'Warnings',
      notifications: 'Notifications'
    },
    modules: {
      dashboard: 'Dashboard',
      usernmngment: 'User Managment',
      repair: 'Maintainance',
      jobs: 'Jobs',
      flow: 'System',
      coding: 'Coding',
      base: 'Base Info'
    }
  },
  validation: {
    username_required: 'Username is Required',
    password_required: 'Password is Required'
  },
  menu: {
    maintenance: {
      cartable: 'Cartable',
      repair_request: 'Vehicle Request',
      content_report: 'Content Report',
      group_performance_report: 'Content Report',
      individual_performance_report: 'Content Report',
      techniqual_agent: 'Unit Statistics',
      commision: 'Vehicle Statistics',
      rent_items: 'Driver Statistics',
      items_list: 'Vehicles',
      companies: 'Drivers List',
      code_to_item: 'Delegation',
      miss_req: 'Driver Costs',
      exit_list: 'Vehicle Costs',
      system_proccess: 'Vehicle Costs'
    },
    base: {
      staff_info: 'Staff Info',
      family_info: 'Family Info',
      other_info: 'Other Info'
    }
  },
  pages: {
    baseInfo: {
      otherInfo: {
        name: 'نام',
        family: 'نام خانوادگی',
        nationalCode1: 'کد ملی',
        nationalCode2: 'شماره شناسنامه',
        fatherName: 'نام پدر',
      }
    }
  }
};

export default en;
