import { Box, styled, Tooltip, Typography } from '@mui/material';
import { Link } from 'react-router-dom';

const LogoWrapper = styled(Link)(
  ({ theme }) => `
        color: ${theme.palette.text.primary};
        padding: ${theme.spacing(0, 1, 0, 0)};
        display: flex;
        text-decoration: none;
        font-weight: ${theme.typography.fontWeightBold};
`
);

const LogoSignWrapper = styled(Box)(
  () => `
        width: 52px;
        height: 38px;
        margin-top: 4px;
        transform: scale(.8);
`
);

const LogoSign = styled(Box)(
  ({ theme }) => `
        background: ${theme.palette.primary.main};
        width: 18px;
        height: 18px;
        border-radius: ${theme.shape.borderRadius}px;
        position: relative;
        transform: rotate(45deg);
        top: 3px;
        left: 17px;

        &:after, 
        &:before {
            content: "";
            display: block;
            width: 18px;
            height: 18px;
            position: absolute;
            top: -1px;
            right: -20px;
            transform: rotate(0deg);
            border-radius: ${theme.shape.borderRadius}px;
        }

        &:before {
            background: ${theme.palette.primary.main};
            right: auto;
            left: 0;
            top: 0;
        }

        &:after {
            background: ${theme.palette.primary.main};
            left: 0;
            bottom: 0;
        }
`
);

const LogoSignInner = styled(Box)(
  ({ theme }) => `
        width: 16px;
        height: 16px;
        position: absolute;
        top: 12px;
        left: 12px;
        z-index: 5;
        border-radius: ${theme.shape.borderRadius}px;
        background: ${theme.palette.primary.contrastText};
`
);

const LogoTextWrapper = styled(Box)(
  ({ theme }) => `
        padding-left: ${theme.spacing(1)};
`
);

const VersionBadge = styled(Box)(
  ({ theme }) => `
        background: ${theme.palette.success.main};
        color: ${theme.palette.success.contrastText};
        padding: ${theme.spacing(0.4, 1)};
        border-radius: ${theme.shape.borderRadius}px;
        text-align: center;
        display: inline-block;
        line-height: 1;
        font-size: ${theme.typography.pxToRem(11)};
        padding: ${theme.spacing(0, 1)};
        margin-left: ${theme.spacing(1)};
`
);

const LogoText = styled(Box)(
  ({ theme }) => `
        font-size: ${theme.typography.pxToRem(22)};
        font-weight: ${theme.typography.fontWeightBold};
`
);

function Logo() {
  return (
    <Tooltip title="سامانه تعمیر و نگهداری" arrow>
      <LogoWrapper to="/">
        <LogoSignWrapper>
          <LogoSign>
            <LogoSignInner />
          </LogoSign>
        </LogoSignWrapper>
        <LogoTextWrapper>
          <Typography variant="h4" component="h2" gutterBottom>
            سامانه تعمیر و نگهداری
          </Typography>
          <VersionBadge>
            نسخه 1.0
          </VersionBadge>
        </LogoTextWrapper>
      </LogoWrapper>
    </Tooltip>
  );
}

export default Logo; 