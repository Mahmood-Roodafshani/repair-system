/* eslint-disable @typescript-eslint/no-explicit-any */
import { TextField } from '@mui/material';
import { UseFormRegister } from 'react-hook-form';

interface CustomInputProps {
  label: string;
  type?: string;
  register: UseFormRegister<any>;
  name: string;
  error?: string;
  helperText?: string;
}

const CustomInput: React.FC<CustomInputProps> = ({
  label,
  type = 'text',
  register,
  name,
  error,
  helperText
}) => {
  return (
    <TextField
      label={label}
      type={type}
      fullWidth
      variant="outlined"
      margin="dense"
      size="small"
      {...register(name)}
      error={!!error}
      helperText={helperText}
    />
  );
};

export default CustomInput;
