# Components

This folder contains the reusable UI components used across the project. Components are independent, modular pieces of code that can be shared between different parts of the application to improve consistency and maintainability.

## Structure

The `components` folder is organized to keep all UI components modular and easy to find. Common components are typically placed in this folder and can include both presentational and container components.

### Common Components in this Folder:

- **Button.js**: A customizable button component.
- **Card.js**: A component used to display content in a card layout.
- **Modal.js**: A component for creating modals (pop-up windows) with customizable content.
- **Input.js**: A component for creating input fields, supporting various types (text, password, etc.).
- **Navbar.js**: A component for the navigation bar used throughout the app.
- **Spinner.js**: A loading spinner component to show during data fetching or processing.

## Usage

To use any component in the project, simply import it and include it in your JSX.

### Example of using the `Button` component:

```javascript
import Button from '@/components/Button';

const App = () => {
  return (
    <div>
      <Button onClick={() => alert('Button clicked!')}>Click Me</Button>
    </div>
  );
};
```
