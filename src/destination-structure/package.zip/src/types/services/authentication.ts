export type LoginUSerBodyType = {
  username: string;
  password: string;
  grant_type: string;
  captcha?: string;
};

export type LoginResponseType = {
  access_token: string;
  refresh_token: string;
  scopes: string[];
  token_type: string;
  expires_in: number;
};
