import { RichViewType } from '@/types/richViewType';

export function findAllParents(nodeId: string, tree: RichViewType[]) {
  const parents: RichViewType[] = [];

  function findParents(node: RichViewType, targetId: string, parentChain: RichViewType[] = []) {
    if (node.id === targetId) {
      parents.push(...parentChain);
      return true;
    }

    if (node.children) {
      for (const child of node.children) {
        findParents(child, targetId, [...parentChain, node]);
      }
    }

    return false;
  }

  for (const node of tree) {
    findParents(node, nodeId);
  }

  return parents;
}

function getIdsWithNonZeroChildren(objects: RichViewType[]) {
  return objects
    .filter((obj) => obj.children && obj.children.length > 0)
    .map((obj) => obj.id);
}

export function findAllNodesWithChild(tree: RichViewType[]) {
  const ids: string[] = [];

  function traverse(nodes: RichViewType[]) {
    for (const node of nodes) {
      if (node.children && node.children.length > 0) {
        ids.push(node.id);
        traverse(node.children);
      }
    }
  }

  traverse(tree);
  return ids;
}

export function findLeafs(arr: RichViewType[]): string[] {
  const leafs: string[] = [];

  function traverse(nodes: RichViewType[]) {
    for (const node of nodes) {
      if (!node.children || node.children.length === 0) {
        leafs.push(node.id);
      } else {
        traverse(node.children);
      }
    }
  }

  traverse(arr);
  return leafs;
} 