# Constants

This folder contains all the constant values and configurations used throughout the project. Constants are typically values that do not change during the application's runtime and can be safely reused across different components, services, or utilities.

## Structure

The `constants` folder may include the following files:

- **apiEndpoints.js**: A file containing API endpoint URLs.
- **config.js**: A file containing configuration settings.
- **statusCodes.js**: A file with HTTP status codes and their descriptions.
- **colors.js**: A file defining color values used throughout the project.
- **appConstants.js**: A file with other general constants related to the application.

## Usage

To use a constant in the project, import the desired constant from the relevant file.

### Example of using API endpoint constants:

```javascript
import { GET_USER, POST_USER } from '@/constants/apiEndpoints.js';

const fetchUserData = async () => {
  const response = await fetch(GET_USER);
  const data = await response.json();
  return data;
};
```
