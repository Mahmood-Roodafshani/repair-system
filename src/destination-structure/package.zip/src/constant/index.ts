export { menus } from './staticMenu';
export { notifications } from './staticMenu';
export { mainSystems } from './staticMenu';
