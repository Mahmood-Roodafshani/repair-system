/* eslint-disable @typescript-eslint/no-explicit-any */
import { lang } from '@/localization';
import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import { toast } from 'react-toastify';
import { store } from '@/redux/store';
import { Typography } from '@mui/material';

const axiosInstance: AxiosInstance = axios.create({
  timeout: 8000
});

axiosInstance.interceptors.request.use(
  (config) => {
    const state = store.getState();
    const token = state?.userInfo.token;
    config.headers['localization'] = lang ?? 'fa';
    if (token) {
      config.headers['Authorization'] = token;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.code === 'ECONNABORTED') {
      toast.error(<Typography variant="body1">errorMsg</Typography>);
    }
    return Promise.reject(error);
  }
);

const fetchRequest = async ({
  url,
  method = 'GET',
  data = null,
  file = null,
  options = {}
}: {
  url: string;
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  data?: any;
  file?: File | null;
  options?: {
    showSuccessMessage?: boolean;
  };
}): Promise<{ data: any; status: number }> => {
  const controller = new AbortController();
  const signal = controller.signal;
  setTimeout(() => controller.abort(), 8000);

  let requestData = data;
  const headers: Record<string, string> = {};

  if (file) {
    const formData = new FormData();
    formData.append('file', file);
    requestData = formData;
    headers['Content-Type'] = 'multipart/form-data';
  }

  try {
    const config: AxiosRequestConfig = {
      url,
      method,
      data: requestData,
      signal,
      headers
    };
    const response = await axiosInstance(config);

    if (options?.showSuccessMessage) {
      toast.success(
        <Typography variant="body1">{response.data.message}</Typography>
      );
    }
    return { status: response.status, data: response.data };
  } catch (error: any) {
    const errorMessage =
      error.response?.data?.message || error.message || 'خطایی رخ داده است';
    toast.error(<Typography variant="body1">{errorMessage}</Typography>);
    return { status: error.response?.status || 500, data: {} };
  }
};

export default fetchRequest;
