export const BASE_URL = 'http://localhost:8000/';

export const API = {
  Authentication: {
    Login: `${BASE_URL}app/signin`
  }
};
