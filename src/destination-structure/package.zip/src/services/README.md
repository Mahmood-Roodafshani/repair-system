# Services

The `services` folder contains reusable components and functions to handle HTTP requests and other services like authentication. It is designed to abstract away the complexity of making API calls and managing the logic for interacting with external resources.

## Folder Structure

- **`service.tsx`**: A reusable service component that provides HTTP request functions, abstracting the logic for making API calls.
- **`authentication.ts`**: Contains functions specifically for handling authentication-related API requests (e.g., login, registration, etc.).

## `service.tsx` - Reusable Service for HTTP Requests

`service.tsx` is a reusable module that provides functions to make HTTP requests (GET, POST, PUT, DELETE). It is designed to simplify making API calls from different parts of the application.

### Example: `service.tsx`

```tsx
import axios, { AxiosRequestConfig } from 'axios';

const API_URL = 'https://api.example.com'; // Base API URL

// Reusable function for making HTTP requests
const makeRequest = async (
  method: string,
  url: string,
  data: any = null,
  config: AxiosRequestConfig = {}
) => {
  try {
    const response = await axios({
      method,
      url: `${API_URL}${url}`,
      data,
      ...config
    });
    return response.data; // Return the response data directly
  } catch (error) {
    console.error('API Error:', error);
    throw error; // Rethrow the error so the caller can handle it
  }
};

// Reusable GET request function
export const get = (url: string, config: AxiosRequestConfig = {}) =>
  makeRequest('GET', url, null, config);

// Reusable POST request function
export const post = (url: string, data: any, config: AxiosRequestConfig = {}) =>
  makeRequest('POST', url, data, config);

// Reusable PUT request function
export const put = (url: string, data: any, config: AxiosRequestConfig = {}) =>
  makeRequest('PUT', url, data, config);

// Reusable DELETE request function
export const del = (url: string, config: AxiosRequestConfig = {}) =>
  makeRequest('DELETE', url, null, config);
```
