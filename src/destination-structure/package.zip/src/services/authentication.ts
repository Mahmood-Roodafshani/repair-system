/* eslint-disable @typescript-eslint/no-explicit-any */
import { API } from './api';
import fetchRequest from './service';

const DoLoginService: (
  body: any
) => Promise<{ data: any; status: number }> = async (body) => {
  return fetchRequest({
    url: API.Authentication.Login,
    method: 'POST',
    data: body
  });
};
export { DoLoginService };
