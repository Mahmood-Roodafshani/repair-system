import { MainRoutes } from '@/routes'
import { Box, Grid2 } from '@mui/material'
import Navbar from './Navbar'
import Sidebar from './Sidebar'

export default function Layout() {
  return (
    <Box sx={{ display: 'flex' }}>
      <Navbar />
      <Sidebar />
      <Grid2 flex={1} padding='10px' pt='70px'>
        <MainRoutes />
      </Grid2>
    </Box>
  )
}
