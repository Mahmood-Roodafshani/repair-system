import { CustomButton } from '@/components'
import { menus } from '@/constant'
import { changeLanguage, translate } from '@/localization'
import { Grid2, List, ListItem, ListItemButton, Typography } from '@mui/material'
import { useTheme } from '@mui/material/styles'
import { Link, useLocation } from 'react-router-dom'

export default function Sidebar() {
  const location = useLocation()
  const firstPathSegment = location.pathname.split('/')[1] as keyof typeof menus
  const theme = useTheme()
  const currentMenu = menus[firstPathSegment] || []

  return (
    <Grid2 marginTop={7} p={1} width='240px' height='100vh' borderRight='1px solid #ccc'>
      <List>
        {currentMenu?.map((item) => (
          <Link to={item.url}>
            <ListItem
              key={item.id}
              disablePadding
              sx={{
                backgroundColor: location.pathname.endsWith(item.url)
                  ? theme.palette.primary.light
                  : undefined,
                '&:hover': {
                  backgroundColor: !location.pathname.endsWith(item.url)
                    ? theme.palette.action.hover
                    : undefined,
                },
              }}
            >
              <ListItemButton dense>
                <Grid2
                  sx={{
                    display: 'flex',
                    justifyContent: 'flex-start',
                    alignItems: 'center',
                    color: location.pathname.endsWith(item.url) ? 'white' : 'unset',
                  }}
                >
                  {item.icon}
                  <Typography
                    sx={{
                      color: location.pathname.endsWith(item.url) ? 'white' : 'unset',
                    }}
                    variant='caption'
                    color='primary'
                    m={1}
                  >
                    {item.title}
                  </Typography>
                </Grid2>
              </ListItemButton>
            </ListItem>
          </Link>
        ))}
      </List>
      <CustomButton label={translate.common.change_lang} onClick={() => changeLanguage()} />
    </Grid2>
  )
}
