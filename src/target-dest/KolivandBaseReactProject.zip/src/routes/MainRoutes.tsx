import { Cartbot, MainPage } from '@/pages'
import { Route, Routes } from 'react-router-dom'

export default function MainRoutes() {
  return (
    <Routes>
      <Route path='/' element={<MainPage />} />
      <Route path='/cart-bot' element={<Cartbot />} />
    </Routes>
  )
}
