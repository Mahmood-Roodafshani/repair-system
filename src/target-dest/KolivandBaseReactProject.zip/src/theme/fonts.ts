import { FontType } from '@/types'

const fonts: FontType = {
  h1: '24px',
  h2: '20px',
  body1: '14px',
  body2: '14px',
  subtitle1: '12px',
  subtitle2: '12px',
  caption: '14px',
}

export default fonts
