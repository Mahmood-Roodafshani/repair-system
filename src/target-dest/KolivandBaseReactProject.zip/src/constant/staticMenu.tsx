import MailIcon from '@mui/icons-material/Mail'
import InboxIcon from '@mui/icons-material/MoveToInbox'
import ReportIcon from '@mui/icons-material/AssessmentRounded'
import { translate } from '@/localization'

export const notifications: {
  id: number
  title: string
  url: string
}[] = [
  { id: 1, title: translate.main_page.info.inbox, url: '/' },
  { id: 2, title: translate.main_page.info.warning, url: '/' },
  { id: 3, title: translate.main_page.info.notifications, url: '/' },
]

export const mainSystems: {
  id: number
  title: string
  url: string
}[] = [
  { id: 1, title: translate.main_page.modules.repair, url: '/maintenance' },
  { id: 2, title: translate.main_page.modules.usernmngment, url: '/settings' },
  { id: 3, title: translate.main_page.modules.jobs, url: '/' },
  { id: 4, title: translate.main_page.modules.flow, url: '/' },
  { id: 5, title: translate.main_page.modules.coding, url: '/' },
  { id: 6, title: translate.main_page.modules.base, url: '/' },
]

const maintenanceMenu = [
  {
    id: 1000,
    title: translate.menu.cartable,
    url: 'maintenance/cart-bot',
    icon: <InboxIcon />,
  },
  {
    id: 1001,
    title: translate.menu.repair_request,
    url: 'maintenance/repair-equest',
    icon: <MailIcon />,
  },
  {
    id: 1002,
    title: translate.menu.content_report,
    url: 'maintenance/content-report',
    icon: <ReportIcon />,
  },
  {
    id: 1003,
    title: translate.menu.group_performance_report,
    url: 'maintenance/group-performance-report',
    icon: <InboxIcon />,
  },
  {
    id: 1004,
    title: translate.menu.individual_performance_report,
    url: 'maintenance/individual-performance-report',
    icon: <MailIcon />,
  },
  {
    id: 1005,
    title: translate.menu.techniqual_agent,
    url: 'maintenance/techniqual_agent',
    icon: <ReportIcon />,
  },
  {
    id: 1006,
    title: translate.menu.commision,
    url: 'maintenance/commision',
    icon: <InboxIcon />,
  },
  {
    id: 1007,
    title: translate.menu.rent_items,
    url: 'maintenance/rent-items',
    icon: <MailIcon />,
  },
  {
    id: 1008,
    title: translate.menu.items_list,
    url: 'maintenance/items-list',
    icon: <ReportIcon />,
  },
  {
    id: 1009,
    title: translate.menu.companies,
    url: 'maintenance/companies',
    icon: <InboxIcon />,
  },
  {
    id: 1010,
    title: translate.menu.code_to_item,
    url: 'maintenance/code-to-item',
    icon: <MailIcon />,
  },
  {
    id: 1011,
    title: translate.menu.miss_req,
    url: 'maintenance/miss-req',
    icon: <MailIcon />,
  },
  {
    id: 1012,
    title: translate.menu.exit_list,
    url: 'maintenance/exit-list',
    icon: <MailIcon />,
  },
  {
    id: 1013,
    title: translate.menu.system_proccess,
    url: 'maintenance/system-proccess',
    icon: <MailIcon />,
  },
]

export const menus = {
  maintenance: maintenanceMenu,
  settings: [
    { id: 3, title: 'تنظیمات عمومی', url: '/settings/general', icon: <MailIcon /> },
    { id: 4, title: 'امنیت', url: '/settings/security', icon: <MailIcon /> },
  ],
  reports: [
    { id: 5, title: 'گزارشات فروش', url: '/reports/sales', icon: <MailIcon /> },
    { id: 6, title: 'گزارشات کاربران', url: '/reports/users', icon: <MailIcon /> },
  ],
}
