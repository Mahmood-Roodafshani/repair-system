import { AuthLayout, MasterLayout } from '@/pages'
import { ConfigInfo } from '@/redux/slices/configSlice'
import { userInfo } from '@/redux/slices/userSlice'
import { useAppSelector } from '@/redux/store'
import { darkTheme, lightTheme, RTLComponent } from '@/theme'
import { CssBaseline } from '@mui/material'
import { ThemeProvider } from '@mui/material/styles'

const App = () => {
  const { themeMode } = useAppSelector(ConfigInfo)
  const { token } = useAppSelector(userInfo)

  return (
    <RTLComponent>
      <ThemeProvider theme={themeMode === 'light' ? lightTheme : darkTheme}>
        <CssBaseline />
        {token ? <MasterLayout /> : <AuthLayout />}
      </ThemeProvider>
    </RTLComponent>
  )
}
export default App
